# From http://openfontlibrary.org/media/files/jonadab/414
font 'bgrove.otf'
font 'bgrove.ttf'
# http://openfontlibrary.org/media/files/chemoelectric/206
font 'Prociono.otf'
stylesheet 'fancy-fonts.sass'
