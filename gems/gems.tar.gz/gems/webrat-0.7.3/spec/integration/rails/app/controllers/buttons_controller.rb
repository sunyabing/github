class ButtonsController < ApplicationController
  def show
  end
  def create
    render :text => "success"
  end
end
