class Application < Merb::Controller
end
