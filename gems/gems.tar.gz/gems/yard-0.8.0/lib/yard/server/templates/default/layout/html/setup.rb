def javascripts
  super + %w(js/autocomplete.js js/live.js)
end

def stylesheets
  super + %w(css/custom.css)
end