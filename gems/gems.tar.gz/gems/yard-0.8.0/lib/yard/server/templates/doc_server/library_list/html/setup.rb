def init
  sections :library_list, [:title, :contents]
end